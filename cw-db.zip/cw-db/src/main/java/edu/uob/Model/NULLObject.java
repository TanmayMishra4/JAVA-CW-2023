package edu.uob.Model;

public class NULLObject {
    @Override
    public String toString(){
        return "";
    }
}
