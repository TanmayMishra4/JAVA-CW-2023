package edu.uob.AllEnums;

public enum AlterationType {
    ADD, DROP
}
