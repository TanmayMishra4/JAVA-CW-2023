package edu.uob.AllEnums;

public enum BoolOperator {
    AND, OR
}
