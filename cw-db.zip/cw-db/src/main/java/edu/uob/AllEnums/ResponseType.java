package edu.uob.AllEnums;

public enum ResponseType {
    ERROR,
    OK
}
