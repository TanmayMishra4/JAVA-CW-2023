package edu.uob.AllEnums;

public enum ValueType {
    STRING, FLOAT, INTEGER, BOOLEAN, NULL
}
