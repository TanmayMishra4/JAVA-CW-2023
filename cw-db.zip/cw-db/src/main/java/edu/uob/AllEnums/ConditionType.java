package edu.uob.AllEnums;

public enum ConditionType {
    BOOL_OPERATOR, SQL_COMPARATOR
}
