package edu.uob.AllEnums;

public enum SQLComparator {
    EQUALS, GREATER_THAN, LESS_THAN, GREATER_EQUALS, LESS_EQUALS, NOT_EQUALS, LIKE
}
